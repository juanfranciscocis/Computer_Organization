int abs_diff(int a, int b) {
    int diff = a - b;
    if (diff < 0) {
        diff = -diff;
    }
    return diff;
}

